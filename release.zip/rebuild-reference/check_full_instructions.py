"""Check frozen geometry, construction coverage, access order and PDF correspondence."""
import argparse,hashlib,json
from pathlib import Path
from collections import Counter
from pypdf import PdfReader
H=Path(__file__).resolve().parent;R=H.parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--dir',type=Path,default=R/'output/yangliu-full-instructions-draft-v1')
p.add_argument('--source',type=Path,default=H/'prototypes/base-75875/dark-orange')
p.add_argument('--pdf',type=Path,default=R/'output/pdf/yangliu-full-instructions-draft-v1.pdf')
args=p.parse_args();D=args.dir
m=json.loads((D/'model.json').read_text());source=json.loads((args.source/'model.json').read_text())
digest=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert digest(args.source/'model.json')==m['instruction_source_sha256']
a={p['id']:{k:v for k,v in p.items() if k!='step'} for p in source['pieces']}
b={p['id']:{k:v for k,v in p.items() if k!='step'} for p in m['pieces']}
assert a==b,'Instruction planning changed a piece or installed pose'
ids=[i for o in m['build_operations'] if o['kind']=='build' for i in o['ids']]
assert len(ids)==len(set(ids))==len(a) and set(ids)==a.keys()
plan=m['instruction_plan'];steps=plan['steps'];n=len(steps)
assert [s['number'] for s in steps]==list(range(1,n+1))
assert set(map(int,plan['operation_to_step']))=={o['step'] for o in m['build_operations']}
assert all(set(s['new_ids'])<=set(s['manual']['ids']) for s in steps)
assert all(s.get('piece_id') in a for s in m.get('extra_decal_surfaces',[]))
introduced={i:s['number'] for s in steps for i in s['new_ids']}
introduced_operation={i:o['step']for o in m['build_operations']for i in o.get('ids',[])}
if m.get('hood_rope_revision'):
    assert introduced_operation[29]<introduced_operation[334]
    assert all(introduced[i]==introduced[334] for i in m.get('hood_alignment_revision',{}).get('orange_wings',[]))
    assert all(introduced[int(i)]==introduced[j] for i,j in m['hood_rope_revision']['trim_fillers'].items())
    assert all(s.get('piece_id') in a for s in m['decal_surfaces'])
    sections={s['name']:s for s in m['hood_sticker_sections']}
    if 'hood-upper' in sections:
        assert set(sections)=={'hood-upper','hood-front'}
        assert set(sections['hood-upper']['piece_ids'])=={334,339,340}
        assert sections['hood-upper']['internal_seam_cut'] is False
        assert {s['piece_id'] for s in m['decal_surfaces'] if s.get('physical_film_group')=='hood-upper'}=={334,339,340}
        upper_note=next(s['manual']['note'] for s in steps if s['manual'].get('art')=='hood')
        assert 'do not cut at the internal tile seams' in upper_note
    else:
        assert len(sections)==4
if m.get('banner_mast_revision'):
    assert all(introduced[i]<introduced[265] for i in m['banner_mast_revision'].get('mount_build_order',[264,341]))
    assert introduced_operation[265]<introduced_operation[266]
    assert introduced[265]<=introduced[266]
    assert introduced[266]==introduced[267]
    assert a[265]['part']==m['banner_mast_revision']['parts']['mast_ldraw']
    assert a[341]['part']=='85861'
if m.get('printed_color_backgrounds'):
    banner_note=next(s['manual']['note'] for s in steps if s['manual'].get('art')=='banner')
    assert 'printed Reddish Orange backgrounds' in banner_note
assert introduced[129]<introduced[287]<introduced[7]
driver_ids={i for i,piece in a.items() if piece['module']=='driver'}
if driver_ids:assert all(introduced[287]<introduced[i]<introduced[7] for i in driver_ids)
if m.get('driver_revision',{}).get('included') is False:assert not driver_ids and all(i not in a for i in range(272,280))
band_steps=[s for s in steps if s['manual'].get('bands_installation')]
if m.get('suspension_bands'):
    assert len(band_steps)==1
    bs=band_steps[0]['number']
    assert all(introduced[i]<bs for i in [227,239,242,247])
    assert all(bs<introduced[i] for i in [221,222,243,244,235,236,249,250])
    assert all(s['manual']['bands_installed']==(s['number']>=bs) for s in steps)
    assert sum(i['quantity'] for i in m['flexible_accessories'] if i.get('bricklink_part')=='x37')==2
jobs=json.loads((D/'instruction-render-jobs.json').read_text())
for name,_ in jobs:assert (D/(name+'.png')).is_file(),name
reader=PdfReader(args.pdf);pages=json.loads((D/'pdf-page-map.json').read_text())
assert len(reader.pages)==pages['pages']
for s in steps:
    text=' '.join(reader.pages[pages['steps'][str(s['number'])]-1].extract_text().split())
    assert s['manual']['title'] in text,(s['number'],s['manual']['title'])
assert digest(args.pdf)==pages['pdf_sha256']
assert (D/'instructions.pdf').read_bytes()==args.pdf.read_bytes()
if m.get('physical_audit'):
    audit=H/m['physical_audit']['report_folder']
    assert digest(audit/'corrected-candidate/model.json')==m['physical_audit']['frozen_candidate_sha256']
    repaired=json.loads((audit/'corrected-candidate/model.json').read_text())
    assert {p['id']:{k:v for k,v in p.items() if k!='step'} for p in repaired['pieces']}==a
    acceptance=json.loads((args.source/'appearance-acceptance.json').read_text())
    assert acceptance['accepted'] and acceptance['model_sha256']==digest(args.source/'model.json')
out=dict(revision=m['revision'],edition=m['instruction_edition'],source_model_sha256=m['instruction_source_sha256'],
 model_sha256=digest(D/'model.json'),pdf_sha256=pages['pdf_sha256'],pieces=len(a),
 lots=len(Counter((p['part'],p['color']) for p in m['pieces'])),public_steps=n,internal_operations=len(m['build_operations']),
 pdf_pages=len(reader.pages),rendered_images=len(jobs),geometry_and_instance_ids_unchanged=True,
 part_introductions_once=True,all_operations_covered=True,all_new_parts_visible=True,
 all_prints_have_part_owners=True,pdf_step_titles_match_plan=True,driver_before_windshield=True if driver_ids else 'not_applicable_driver_omitted',
 suspension_bands_before_wheels=bool(band_steps),external_build_steps=0,
 physical_strength='not_evaluated',construction_insertion='targeted access checks; full sequence not certified',
 limits='Digital audit repairs and targeted interfaces checked. Real-brick grip, suspension response and handling strength remain untested.')
(D/'full-instruction-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
