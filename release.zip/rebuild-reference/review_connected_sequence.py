"""Review exact-pose instruction prefixes and bounded, multi-direction approaches.

Graph gaps, surface crossings, insertion and physical grip are separate results.
"""
import argparse,hashlib,json,sys
from collections import defaultdict,Counter
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree

H=Path(__file__).resolve().parent;ROOT=H.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from lego_contact_review import triangles
from lego_ldraw import catalog_pose
from audit_final_minifigure import crossings
from mesh_approach_screen import SurfaceScreen
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--dir',type=Path,required=True)
ap.add_argument('--evidence',type=Path,required=True)
ap.add_argument('--mesh-paths',action='store_true')
ap.add_argument('--source',type=Path,default=H/'prototypes/final-fit-v6')
ap.add_argument('--connections',type=Path,default=H/'prototypes/final-fit-v6/catalog-connections.json')
args=ap.parse_args();D=args.dir;E=args.evidence;E.mkdir(parents=True,exist_ok=True)
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):(E/name).write_text(json.dumps(data,indent=2)+'\n')
m=load(D/'model.json');source=load(args.source/'model.json')
canon=lambda m:{p['id']:{k:v for k,v in p.items()if k!='step'}for p in m['pieces']}
assert canon(m)==canon(source)
ps={p['id']:p for p in m['pieces']};cat=load(D/'catalog-meshes.json')
cs=load(args.connections)['contacts']
graph=defaultdict(set)
for r in cs:
    a,b=r['piece_ids'];graph[a].add(b);graph[b].add(a)
def components(ids):
    todo=set(ids);out=[]
    while todo:
        stack=[todo.pop()];c=set(stack)
        while stack:
            for x in graph[stack.pop()]&todo:todo.remove(x);c.add(x);stack.append(x)
        out.append(c)
    return sorted(out,key=lambda c:(-len(c),min(c)))
mesh={};bounds={}
for i,p in ps.items():
    part,t,r=catalog_pose(p);mesh[i]=triangles(cat['parts'][part])@r.T+t
    bounds[i]=(mesh[i].min((0,1)),mesh[i].max((0,1)))
states=defaultdict(set);prefixes=[];snapshots=[];seeds={};assembly_final=defaultdict(set)
for op in m['build_operations']:
    if op['kind']=='build':assembly_final[op['assembly']].update(op['ids'])
    else:assembly_final[op['assembly']].update(assembly_final[op['child']])
for op in m['build_operations']:
    a=op['assembly'];old=set(states[a]);new=set(op['ids'])if op['kind']=='build'else set(states[op['child']]);states[a]|=new
    if not new:continue
    if not old:seeds[a]=set(new)
    final_components=components(assembly_final[a]);final_root=set().union(*(c for c in final_components if c&seeds[a]))
    comps=components(states[a]);unattached=[c for c in comps if not c&seeds[a]]
    rows=[]
    for c in unattached:
        future=set().union(*(graph[i]for i in c))-states[a]
        rows.append(dict(ids=sorted(c),future_neighbors=sorted(future),
            classification='future_connection_order'if c&final_root else'final_catalog_graph_gap'))
    prefixes.append(dict(operation=op['step'],public_step=m['instruction_plan']['operation_to_step'][str(op['step'])],
        assembly=a,kind=op['kind'],new_ids=sorted(new),seed=not bool(old),components=rows))
    snapshots.append((op,old,new))
save('connected-prefixes.json',dict(model_sha256=sha(D/'model.json'),source_sha256=sha(args.source/'model.json'),connection_report_sha256=sha(args.connections),
    exact_piece_geometry_color_and_instance_identity=True,operations=prefixes,
    limits='Confirmed and potential catalog edges are retained separately in the original source report. A final graph gap is unresolved metadata or construction evidence, not proof of physical failure. Table seeds are explicit separate assemblies.'))
order=[r for r in prefixes if any(c['classification']=='future_connection_order'for c in r['components'])]
print('Prefix review:',len(prefixes),'nonempty operations;',len(order),'with temporal catalog-graph findings',flush=True)
for r in order:print(r['public_step'],r['assembly'],[c['ids']for c in r['components']if c['classification']=='future_connection_order'],flush=True)

# Shape comparison uses the real catalog vertices and exact source transforms.
repeats=[]
for name,pairs,anchor in [
    ('Running boards, 2 copies',[(97,158),(96,166),(115,156),(117,185),(197,205),(140,176),(98,167),(116,157)],(96,166)),
    ('Speakers, 2 copies',list(zip(range(288,294),range(294,300))),(288,294)),
    ('Life rings, 2 copies',[(268,270),(269,271)],(268,270)),
    ('Wheels, rear pair',[(221,243),(222,244)],(221,243)),
    ('Wheels, front left',[(221,235),(222,236)],(221,235)),
    ('Wheels, front right',[(221,249),(222,250)],(221,249)),
    *([('Platform risers, copy '+str(k),[(280,b),(326,c)],(280,b))for k,b,c in [(2,281,327),(3,282,328),(4,283,329)]]if 2001 in ps else[]),
    *([('Shield panels, copy '+str(k),[(2003,a),(2006,b),(2009,c)],(2006,b))for k,a,b,c in [(2,2004,2007,2010),(3,2005,2008,2011)]]if 2001 in ps else[])]:
    _,ta,ra=catalog_pose(ps[anchor[0]]);_,tb,rb=catalog_pose(ps[anchor[1]]);r=rb@ra.T;t=tb-r@ta
    rows=[]
    for a,b in pairs:
        assert(ps[a]['part'],ps[a]['color'])==(ps[b]['part'],ps[b]['color'])
        av=(mesh[a]@r.T+t).reshape(-1,3);bv=mesh[b].reshape(-1,3)
        error=max(cKDTree(bv).query(av)[0].max(),cKDTree(av).query(bv)[0].max())
        rows.append(dict(ids=[a,b],maximum_vertex_set_residual_ldu=float(error)))
    repeats.append(dict(name=name,part_color_match=True,rigid_transform=dict(rotation=r.tolist(),translation=t.tolist()),
        shape_comparison_tolerance_ldu=.001,exact_source_poses_preserved=True,matching=all(r['maximum_vertex_set_residual_ldu']<.001 for r in rows),parts=rows))
assert all(r['matching']for r in repeats),[(r['name'],r['parts'])for r in repeats if not r['matching']]
save('repeat-recipes.json',dict(recipes=repeats,limits='The tolerance compares exported geometry; it is not a part clearance or physical-fit tolerance. Full left/right side carriers are different, mirrored recipes; only their matching eight-part running boards use 2x.'))

screen=SurfaceScreen(mesh)
screen_controls=[]
for a,b in [(96,97),(96,39),(38,14)]:
    expected=crossings(mesh[a],mesh[b]);actual=screen.crossings(a,b)
    assert np.array_equal(expected,actual),(a,b,expected.shape,actual.shape)
    screen_controls.append(dict(ids=[a,b],same_strict_crossing_points=True,points=len(actual)))
assert not len(screen.crossings(96,97,[10000,10000,10000]))
save('surface-screen-controls.json',dict(actual_pairs=screen_controls,translated_negative_control=True,
    baseline_predicate_sha256=sha(H/'audit_final_minifigure.py'),accelerator_sha256=sha(H/'mesh_approach_screen.py')))
cached={};retained_report=None
previous=E/'sampled-carrier-approaches.json'
if previous.exists()and args.mesh_paths:
    prior=load(previous)
    if prior['model_sha256']==sha(D/'model.json'):
        retained_report='sampled-carrier-approaches-retained-'+sha(previous)[:12]+'.json'
        (E/retained_report).write_bytes(previous.read_bytes())
        cached={(p['operation'],p['from_direction']):p for p in prior['paths']}
axes=[('above',[0,-1,0]),('below',[0,1,0]),('right',[1,0,0]),('left',[-1,0,0]),('front',[0,0,1]),('rear',[0,0,-1])]
sweeps=[];narrow=[]
for op,fixed,moving in snapshots:
    if not fixed:continue
    for name,v in axes:
        v=np.array(v);k=int(np.flatnonzero(v)[0]);other=[i for i in range(3)if i!=k]
        # Enough travel to put the entire moving assembly outside fixed bounds.
        flo=np.min([bounds[i][0]for i in fixed],axis=0);fhi=np.max([bounds[i][1]for i in fixed],axis=0)
        mlo=np.min([bounds[i][0]for i in moving],axis=0);mhi=np.max([bounds[i][1]for i in moving],axis=0)
        travel=float((fhi[k]-mlo[k]if v[k]>0 else mhi[k]-flo[k])+20);travel=max(20,travel)
        candidates=[]
        for a in sorted(moving):
            lo,hi=bounds[a]
            for b in sorted(fixed):
                blo,bhi=bounds[b]
                if np.any(np.minimum(hi[other],bhi[other])-np.maximum(lo[other],blo[other])<=1e-4):continue
                interval=[blo[k]-hi[k],bhi[k]-lo[k]]if v[k]>0 else[lo[k]-bhi[k],hi[k]-blo[k]]
                start=max(0,float(interval[0]));end=min(travel,float(interval[1]))
                if end>start+1e-4:candidates.append(dict(ids=[a,b],overlap_interval_ldu=[start,end]))
        row=dict(operation=op['step'],public_step=m['instruction_plan']['operation_to_step'][str(op['step'])],assembly=op['assembly'],
            moving_ids=sorted(moving),fixed_ids=sorted(fixed),from_direction=name,vector_ldraw=v.tolist(),travel_ldu=travel,
            broadphase_candidates=candidates,aabb_clear=not candidates)
        sweeps.append(row)
        if args.mesh_paths and op.get('child')in['left-side-carrier','right-side-carrier','rear-bed']:
            prior=cached.get((op['step'],name))
            if prior:
                assert all(prior[k]==v for k,v in row.items()if k!='broadphase_candidates'),('Stale approach',op['step'],name)
                prior=dict(prior,reused_from_report=retained_report);narrow.append(prior)
                print('Retained exact-input approach',op['child'],name,flush=True)
                continue
            hits=[];tested=0
            for pair in candidates:
                a,b=pair['ids'];start,end=pair['overlap_interval_ldu']
                offsets=sorted(set([0.,1.,2.,4.,8.,16.,32.,64.,128.,travel,(start+end)/2]))
                for offset in offsets:
                    if offset<start-1e-4 or offset>end+1e-4:continue
                    tested+=1
                    # Both edge directions catch asymmetric mesh intersections.
                    points=screen.pair(a,b,v*offset)
                    if len(points):hits.append(dict(ids=[a,b],offset_ldu=offset,crossing_points=len(points),sample_points_ldu=points[:4].tolist(),
                        catalog_pair_reported=any(set(r['piece_ids'])=={a,b}for r in cs)))
            narrow.append(dict(**{k:v for k,v in row.items()if k!='broadphase_candidates'},tested_pair_poses=tested,surface_crossings=hits,
                status='surface_crossings_need_classification'if hits else'no_proper_crossing_at_tested_poses'))
            print('Mesh approach',op['child'],name,'poses',tested,'crossing poses',len(hits),flush=True)
            save('sampled-carrier-approaches.json',dict(model_sha256=sha(D/'model.json'),paths=narrow,
                limits='Finite poses and strict surface crossings only; not continuous collision, containment, coplanar contact, snap flexure, hand access or grip/strength proof. A reported mating pair is not an exemption.'))
save('six-direction-broadphase.json',dict(model_sha256=sha(D/'model.json'),paths=sweeps,
    limits='Swept axis-aligned mesh boxes can establish empty corridors only. Overlapping boxes require actual geometry review; they do not establish a collision. No insertion direction is inferred from a passing box test.'))

# The old sequence is a negative control for the specific side-panel defect.
old=load(ROOT/'output/yangliu-minifigure-test-build-v6/model.json')
old21=set(old['instruction_plan']['steps'][20]['manual']['ids'])
assert 117 in old21 and not(graph[117]&old21)
for step in m['instruction_plan']['steps']:
    if step['manual'].get('unit_name')in['left side carrier','right side carrier','rear bed']:
        visible=set(step['manual']['ids']);comp=next(c for c in components(visible)if 172 in c)
        assert set(step['new_ids'])<=comp,(step['number'],set(step['new_ids'])-comp)
save('controls.json',dict(old_step_21_isolated_slope_detected=True,new_carriers_connected_at_installation=True,
    original_poses_and_inventory_preserved=True,temporal_graph_findings=len(order),
    nonempty_operations=len(prefixes),broadphase_directions=len(axes),repeat_shape_checks=len(repeats)))
print('Review evidence saved:',E,flush=True)
