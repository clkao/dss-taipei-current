"""Standalone visual prototype: 小英 and one two-sided speech-bubble banner.

Uses catalog minifigure parts and a real 3.2 mm bar/clip flag. This is a
likeness/prop prototype, not an approved addition to the vehicle release.
"""
import copy,hashlib,json,math,sys,uuid
from collections import Counter
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from PIL import Image,ImageDraw,ImageFont
H=Path(__file__).resolve().parent;ROOT=H.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from lego_ldraw import write_exports,catalog_pose,TO_LDRAW
from lego_instruction_plan import renumber
from ldraw.parts import Parts
D=ROOT/'output/yangliu-tsai-prototype';D.mkdir(exist_ok=True)
ART=H/'accessories/tsai-banner';ART.mkdir(parents=True,exist_ok=True)
S=H/'prototypes/final-fit-v6/model.json';source=json.loads(S.read_text());old={p['id']:p for p in source['pieces']}
ps=[];offset=np.array([-2.45,-4.,-7.21875336])
for n,i in enumerate([255,256,257,258,259,260,262,263],400):
    p=copy.deepcopy(old[i]);p.update(id=n,module='tsai',instance_id=str(uuid.uuid5(uuid.NAMESPACE_URL,f'yangliu/tsai-prototype/{n}')))
    p['transform']['origin']=(np.array(p['transform']['origin'])+offset).tolist();p.pop('step',None)
    # The old donor's rounded limb matrices contain tiny scale errors. New
    # figure poses use proper rigid rotations, without editing the vehicle.
    u,_,vt=np.linalg.svd(np.array(p['transform']['matrix']));p['transform']['matrix']=(u@vt).tolist()
    if i==256:p.update(part='973',color='silver',label='Light gray jacket / custom shirt decal')
    if i in[257,258]:p.update(color='silver',label='Light gray sleeve')
    if i==263:p.update(part='62711',label='Short black bob')
    if i==262:p['label']='Glasses and smile / likeness approximation'
    ps.append(p)
# Solve two real joint rotations: shoulder hinge and hand rotation around its
# wrist post. The bar follows the exact nominal hand-clip feature, upright.
arm_index,hand_index=3,5
pivot=np.array(ps[arm_index]['transform']['origin'])
hand0=copy.deepcopy(ps[hand_index]);arm0=copy.deepcopy(ps[arm_index])
lib=Parts(H/'evidence/white-clip-mast-audit/catalog-v2/parts.lst');lib.add_connection_shadow(ROOT/'tmp/ldcad-shadow')
clip=next(f for f in lib.connection_metadata('3820').features if str(f.kind)=='clip')
clip_axis=np.array([clip.axis.x,clip.axis.y,clip.axis.z]);clip_pos=np.array([clip.position.x,clip.position.y,clip.position.z])
def hinge(theta):
    a=math.radians(theta);return np.array([[math.cos(a),0,math.sin(a)],[0,1,0],[-math.sin(a),0,math.cos(a)]])
def spin(phi):
    a=math.radians(phi);return np.array([[math.cos(a),-math.sin(a),0],[math.sin(a),math.cos(a),0],[0,0,1.]])
def hand_rotation(angles):return TO_LDRAW@hinge(angles[0])@np.array(hand0['transform']['matrix'])@TO_LDRAW.T@spin(angles[1])
def objective(angles):
    h=hand_rotation(angles)@clip_axis;return h/np.linalg.norm(h)-np.array([0,-1.,0])
solutions=[least_squares(objective,start,bounds=([-120,-360],[140,360]),gtol=1e-12,ftol=1e-12,xtol=1e-12)for start in[[60,0],[60,180],[-60,0],[-60,180]]]
good=[s for s in solutions if np.linalg.norm(s.fun)<1e-7]
assert good,'No upright hand/bar pose'
solution=min(good,key=lambda s:round(abs(s.x[0]-60)+abs(s.x[1])*.01,7));angles=np.round(solution.x,8);r=hinge(angles[0])
for p in[ps[arm_index],ps[hand_index]]:
    p['transform']['origin']=(pivot+r@(np.array(p['transform']['origin'])-pivot)).tolist()
    p['transform']['matrix']=(r@np.array(p['transform']['matrix'])).tolist()
ps[hand_index]['transform']['matrix']=(TO_LDRAW.T@hand_rotation(angles)@TO_LDRAW).tolist()

def native(pid,part,color,pos,rotation,label,module='tsai'):
    p=dict(id=pid,part=part,color=color,x=-.5,y=-.5,z=-1,w=1,d=1,h=1,kind='catalog-special',module=module,label=label,
        instance_id=str(uuid.uuid5(uuid.NAMESPACE_URL,f'yangliu/tsai-prototype/{pid}')),
        transform=dict(origin=(TO_LDRAW.T@np.asarray(pos)/20).tolist(),matrix=(TO_LDRAW.T@rotation@TO_LDRAW).tolist()))
    ps.append(p);return p
_,hand_pos,hand_r=catalog_pose(ps[hand_index])
grip=hand_pos+hand_r@clip_pos
up=hand_r@clip_axis;up/=np.linalg.norm(up)
normal=np.array([1.,0,0]);normal-=up*(normal@up);normal/=np.linalg.norm(normal)
down=-up;flag_r=np.column_stack((normal,down,np.cross(normal,down)))
bar_pos=grip+up*60
bar=native(408,'30374','white',bar_pos,flag_r,'White 4L handheld banner bar')
flag=native(409,'2335','white',bar_pos,flag_r,'One white two-sided speech-bubble banner')
native(410,'3031','black',np.array([10,-8,0]),np.eye(3),'Optional 4 x 4 display base','display-base')
for p in ps:
    p['transform']['origin']=np.round(p['transform']['origin'],10).tolist()
    p['transform']['matrix']=np.round(p['transform']['matrix'],10).tolist()

font='/System/Library/Fonts/STHeiti Medium.ttc'
phrases={'bubble-rest':'叫你休息','bubble-listen':'講不聽'}
for name,text in phrases.items():
    im=Image.new('RGBA',(768,768),'white');draw=ImageDraw.Draw(im)
    draw.rounded_rectangle((52,70,716,615),radius=135,fill='white',outline='#20272b',width=12)
    draw.polygon([(205,608),(112,700),(325,608)],fill='white')
    draw.line([(205,614),(112,700),(325,614)],fill='#20272b',width=12)
    lines=['叫你','休息']if name=='bubble-rest'else['講不聽'];size=205 if len(lines)==2 else 185
    f=ImageFont.truetype(font,size)
    for k,line in enumerate(lines):draw.text((384,265+215*k if len(lines)==2 else 360),line,font=f,fill='#20272b',anchor='mm')
    im.save(ART/(name+'.png'))
    spans=''.join(f'<text x="384" y="{305+215*k if len(lines)==2 else 405}" text-anchor="middle" font-family="Heiti TC, sans-serif" font-size="{size}" fill="#20272b">{line}</text>'for k,line in enumerate(lines))
    (ART/(name+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="15.2mm" height="15.2mm" viewBox="0 0 768 768"><rect width="768" height="768" fill="white"/><path d="M190 70 H578 Q716 70 716 208 V477 Q716 615 578 615 H325 L112 700 L205 615 H190 Q52 615 52 477 V208 Q52 70 190 70 Z" fill="white" stroke="#20272b" stroke-width="12"/>{spans}</svg>')
# Shirt opening and lapels are a proposed custom decal, not a claimed catalog
# print. Keep the new artwork and exact material dependency explicit.
im=Image.new('RGBA',(512,512),(0,0,0,0));draw=ImageDraw.Draw(im)
draw.polygon([(155,0),(357,0),(306,400),(206,400)],fill='white')
draw.line([(154,0),(100,155),(190,215),(150,310),(225,500)],fill='#555c60',width=10)
draw.line([(358,0),(412,155),(322,215),(362,310),(287,500)],fill='#555c60',width=10)
im.save(ART/'jacket.png')

scene_from_ld=np.diag([1.,-1.,-1.])/20
def surface(piece,local,art,uv):
    _,pos,rot=catalog_pose(piece)
    return dict(module=piece['module'],piece_id=piece['id'],artwork=art,vertices=((np.asarray(local)@rot.T+pos)@scene_from_ld.T).tolist(),uv=uv,indices=[0,1,2,0,2,3])
surfaces=[
    surface(flag,[[-2.08,.8,10.8],[-2.08,.8,49.2],[-2.08,39.2,49.2],[-2.08,39.2,10.8]],'bubble-listen',[[0,1],[1,1],[1,0],[0,0]]),
    surface(flag,[[2.08,.8,49.2],[2.08,.8,10.8],[2.08,39.2,10.8],[2.08,39.2,49.2]],'bubble-rest',[[0,1],[1,1],[1,0],[0,0]]),
    surface(ps[1],[[-14.2,2,-10.08],[14.2,2,-10.08],[18.5,31,-10.08],[-18.5,31,-10.08]],'jacket',[[0,1],[1,1],[1,0],[0,0]])]
for s in surfaces:
    if s['artwork'].startswith('bubble-'):s['uv']=[[1-u,v]for u,v in s['uv']]
m=copy.deepcopy(source)
for key in ['instruction_plan','physical_audit','decal_surfaces','extra_decal_surfaces','suspension_bands','hood_sticker_sections','banner_sticker_sections']:m.pop(key,None)
m.update(pieces=ps,prototype=True,revision='yangliu-tsai-speech-bubble-prototype-1',cord=False,extra_decal_surfaces=surfaces,
    surface_artworks={name:str((ART/(name+'.png')).relative_to(H))for name in[*phrases,'jacket']},
    dimensions_note='Standalone 小英 likeness prototype with a two-sided hand-held speech-bubble banner.',
    limits=['Visual prototype; no likeness acceptance yet.','Plain 973 torso uses a proposed custom jacket decal.','White 2335 flag has one decal on each face; this is a speech-bubble graphic on a real rectangular flag.','Grip axis uses nominal LDCad hand metadata, explicitly approximate; physical hand/bar/clip fit remains untested.'])
m['assembly_roots']={mod:mod for mod in ['tsai','display-base']}
m['build_operations']=[dict(kind='build',module=mod,assembly=mod,ids=[p['id']for p in ps if p['module']==mod],direction='seed',section_name='Visual prototype',placements=[])for mod in m['assembly_roots']]
renumber(m);raw=json.dumps(m,ensure_ascii=False,indent=2).encode();(D/'model.json').write_bytes(raw)
rt=write_exports(m,D,model_sha256=hashlib.sha256(raw).hexdigest())
(D/'yangliu-shape.mpd').write_bytes((D/'clkao-house.mpd').read_bytes())
(D/'prototype-summary.json').write_text(json.dumps(dict(revision=m['revision'],pieces=len(ps),lots=len(Counter((p['part'],p['color'])for p in ps)),modules=dict(Counter(p['module']for p in ps)),mpd_roundtrip=rt),indent=2)+'\n')
(D/'inventory.csv').write_text('ldraw_part,color,quantity\n'+''.join(f'{part},{color},{n}\n'for(part,color),n in sorted(Counter((p['part'],p['color'])for p in ps).items())))
(ART/'prototype-notes.json').write_text(json.dumps(dict(base_source=str(S.relative_to(ROOT)),source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),
    figure_name='蔡英文 / 小英',phrases=phrases,single_banner=True,faces=2,parts=len(ps),display_base_optional=True,source_pose_approximation='Existing figure joints reused; shoulder hinge and wrist-post twist align the nominal grip axis upright.',joint_angles_degrees=angles.tolist(),upright_axis_residual=float(np.linalg.norm(solution.fun)),
    custom_artwork=['speech bubble on each flag face','jacket opening and lapels'],catalog_geometry='Original LDraw meshes; no invented speech-bubble part.',limits=m['limits']),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(out=str(D),pieces=len(ps),mpd_roundtrip=rt),indent=2))
