import fs from 'node:fs';
import {build} from 'esbuild';
import {gzipSync} from 'node:zlib';
const dir=process.argv[2]||'projects/yangliu-vehicle/prototypes/v1';
const compact=process.argv.includes('--panel');
const read=n=>JSON.parse(fs.readFileSync(`${dir}/${n}`));
const model=read('model.json');
const data={model,placements:read('render-scene.json'),catalog:read('catalog-meshes.json'),summary:read('prototype-summary.json'),hoodArtwork:fs.readFileSync(`projects/yangliu-vehicle/${model.hood_artwork||'sources/artwork-v2/hood.png'}`).toString('base64')};
data.procurement=fs.existsSync(`${dir}/bricklink-mapping.json`)?read('bricklink-mapping.json'):null;
data.surfaceArtworks=Object.fromEntries(Object.entries(model.surface_artworks||{}).map(([k,f])=>[k,fs.readFileSync('projects/yangliu-vehicle/'+f).toString('base64')]));
if(compact){
 data.partIcons=read('part-icons.json');
 data.recipeIcons=Object.fromEntries(model.instruction_plan.steps.filter(s=>s.manual.instance_frames?.length).map(s=>[s.number,s.manual.instance_frames.at(-1).image]));
 data.preassembledIcons=Object.fromEntries(model.instruction_plan.steps.flatMap(s=>s.manual.preassembled?[[s.module,s.manual.image]]:(s.manual.instance_frames||[]).filter(f=>f.preassembled).map(f=>[s.module,f.image])));
 if(process.argv.includes('--embed-tray'))Object.assign(data,read('viewer-thumbnails.json'));
}
const mpdName=fs.existsSync(`${dir}/yangliu-shape.mpd`)?'yangliu-shape.mpd':'yangliu-v2.mpd';
const js=(await build({entryPoints:['projects/yangliu-vehicle/preview.js'],bundle:true,write:false,format:'iife',minify:true})).outputFiles[0].text;
const payload=JSON.stringify(data).replaceAll('<','\\u003c');
const bootstrap=compact?`<script>(async()=>{const bytes=Uint8Array.from(atob("${gzipSync(payload).toString('base64')}"),c=>c.charCodeAt(0));const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));window.PROTOTYPE=JSON.parse(await new Response(stream).text());${js}})().catch(error=>{console.error(error);document.querySelector('.note').textContent='Preview could not load: '+error.message});</script>`:`<script>window.PROTOTYPE=${payload}</script><script>${js}</script>`;
fs.writeFileSync(`${dir}/viewer.html`,`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>DSS Taipei Current / 洋流號 — minifigure edition</title>
<style>*{box-sizing:border-box}body{margin:0;color:#202d39;background:#f7f4ee;font:15px -apple-system,BlinkMacSystemFont,sans-serif}header{height:100px;padding:22px 32px;border-bottom:1px solid #d8d0c4;display:flex;justify-content:space-between;align-items:center}h1{margin:0;font-size:28px;letter-spacing:.04em}header p{margin:5px 0;color:#6c7377}.tag{color:#a44522;background:#f6e0d2;border-radius:20px;padding:8px 14px;font-size:12px;font-weight:700}main{display:grid;grid-template-columns:1fr 300px;height:calc(100vh - 100px)}.stage{position:relative;min-height:500px}canvas{width:100%;height:100%;display:block}.toolbar{position:absolute;bottom:22px;left:25px;display:flex;gap:6px;flex-wrap:wrap}button{border:1px solid #bfb5a6;background:#fffdf9;color:#283844;padding:9px 12px;border-radius:7px;cursor:pointer}button:hover{background:#f5d6c4}aside{padding:23px;border-left:1px solid #d8d0c4;overflow:auto}h2{font-size:16px;margin:0 0 12px}#modules label{display:flex;gap:8px;padding:7px 0;align-items:center;font-size:13px}small{margin-left:auto;color:#797c7c}input{accent-color:#d66735}aside p{font-size:12px;line-height:1.55;color:#6b7378}.metric{font-size:22px;font-weight:650;margin:0 0 6px}.selection{margin-top:20px;border-top:1px solid #ddd3c6;padding-top:18px}pre{font-size:11px;white-space:pre-wrap;word-break:break-word;color:#64717a}.note{position:absolute;top:20px;left:25px;font-size:12px;color:#737d80}a{color:#a84d2b}@media(max-width:800px){main{grid-template-columns:1fr;height:auto}.stage{height:65vh}aside{border-left:0}header{height:auto;padding:15px}h1{font-size:22px}}</style>
<header><div><h1>洋流號 <span style="font-weight:350">/ DSS TAIPEI CURRENT</span></h1><p>Minifigure edition · ${data.model.revision}</p></div><span class="tag">${model.instruction_plan?(model.physical_audit?'TEST-BUILD EDITION':'INSTRUCTION DRAFT'):'DESIGN PROTOTYPE'}</span></header>
<main><div class="stage"><canvas></canvas><div class="note">Drag to orbit · scroll to zoom · click any piece</div><div class="toolbar"><button data-view="front">Front ¾</button><button data-view="rear">Rear ¾</button><button data-view="side">Side</button><button id="road">Road configuration</button><button id="all">Launch configuration</button><button id="cabin">Inspect cabin</button></div></div>
<aside><div class="metric">${data.summary.pieces} pieces</div><p>${model.physical_audit?'Rigid count; suspension bands, campaign stickers and craft cord are separate.':'Preliminary count includes figure parts and assembled catalog elements.'} ${data.model.dimensions_note||'8-stud body · 24-stud length · approximately 19 × 7 × 15 cm.'}</p><h2>Detachable equipment</h2><label><input id="explode" type="checkbox"> Explode the modules</label><div id="modules"></div><div class="selection"><h2>Piece reference</h2><pre id="selected">Click a piece to inspect its stable reference.</pre><button id="copy">Copy reference</button></div><p>${model.physical_audit?'Digital fit audit complete. Real-brick grip, band tension, suspension travel and handling strength remain untested. '+(model.driver_revision?.included===false?'Fit the cabin seat before the windscreen; the driver figure is omitted.':'Assemble the seat and driver before the windshield.'):'Actual LDraw catalog meshes. Shape and accessory review only. Interfaces remain provisional.'}</p><p>Candidate: leaf-print shirt approximation, glasses and accepted short hair 98385.</p><p><a href="${mpdName}">Model MPD</a> · <a href="preliminary-inventory.csv">Rigid inventory</a></p><p class="disclaimer">An independent fan design for use with genuine LEGO® bricks. Not affiliated with, sponsored by, or endorsed by the LEGO Group.</p><details><summary>Catalog attribution</summary><pre>${JSON.stringify(data.catalog.attribution,null,1).replaceAll('<','&lt;')}</pre></details></aside></main>
${bootstrap}</html>`);
if(compact){
 let html=fs.readFileSync(`${dir}/viewer.html`,'utf8');
 html=html.replace('Minifigure edition · '+model.revision,'Minifigure edition · local preview');
 let markup=fs.readFileSync('projects/yangliu-vehicle/viewer_panel.html','utf8').replace('327 rigid pieces · 117 build steps',`${model.pieces.length} rigid pieces · ${model.instruction_plan.steps.length} build steps`);
 // Local preview uses the same controls as the release; absent downloads keep
 // their published destinations until the new release package is accepted.
 if(!process.argv.includes('--release'))markup=markup.replace(/href="([^"]+)"/g,(all,url)=>url.startsWith('http')||url.startsWith('#')||fs.existsSync(`${dir}/${url}`)?all:`href="https://yangliu-lego.netlify.app/${url}"`);
 html=html.replace(/<aside>.*?<\/aside><\/main>/s,markup);
 html=html.replace('</style>',fs.readFileSync('projects/yangliu-vehicle/viewer_panel.css','utf8')+'</style>');
 const pdf=fs.existsSync(`${dir}/instructions.pdf`)?['instructions.pdf','Download instructions (PDF)']:['https://yangliu-lego.netlify.app/instructions.pdf','Published PDF (previous sequence)'];
 html=html.replace(/<span class="tag">.*?<\/span>/,`<nav aria-label="Downloads"><a class="pdf-link" href="${pdf[0]}">${pdf[1]}</a></nav>`);
 html=html.replace('</style>','.pdf-link{display:inline-block;background:#a84d2b;color:#fff;padding:11px 16px;border-radius:7px;font-weight:700;text-decoration:none;white-space:nowrap}header{height:auto;min-height:100px;gap:16px;flex-wrap:wrap}</style>');
 fs.writeFileSync(`${dir}/viewer.html`,html);
}
console.log(`${dir}/viewer.html`);
