"""AABB-tree acceleration of the existing strict edge/triangle surface screen.

This changes candidate lookup only. The crossing predicate and its limitations
match audit_final_minifigure.crossings; it is not a solid collision checker.
"""
import numpy as np

class SurfaceScreen:
    def __init__(self,meshes):
        self.meshes=meshes;self.edges={};self.trees={}
        self.bounds={k:(t.min(1),t.max(1))for k,t in meshes.items()}

    def edge_set(self,key):
        if key not in self.edges:
            a=self.meshes[key]
            edges=np.concatenate((a[:,[0,1]],a[:,[1,2]],a[:,[2,0]]))
            self.edges[key]=np.unique(np.round(edges,5).reshape(-1,6),axis=0).reshape(-1,2,3)
        return self.edges[key]

    def tree(self,key):
        if key not in self.trees:
            tris=self.meshes[key];lo=tris.min(1);hi=tris.max(1);centers=(lo+hi)*.5
            def node(ids):
                lower=lo[ids].min(0);upper=hi[ids].max(0)
                if len(ids)<=24:return(lower,upper,ids,None,None)
                axis=int(np.argmax(upper-lower));ids=ids[np.argsort(centers[ids,axis])];mid=len(ids)//2
                return(lower,upper,None,node(ids[:mid]),node(ids[mid:]))
            self.trees[key]=(node(np.arange(len(tris))),lo,hi)
        return self.trees[key]

    def crossings(self,a,b,offset=(0,0,0)):
        """Translate source mesh a; target b and its tree stay at exact poses."""
        root,lo,hi=self.tree(b);target=self.meshes[b];hits=[];offset=np.asarray(offset)
        edges=self.edge_set(a)+offset
        mask=np.all(edges.max(1)>root[0]+1e-5,1)&np.all(edges.min(1)<root[1]-1e-5,1)
        for start,end in edges[mask]:
            lower=np.minimum(start,end);upper=np.maximum(start,end);pending=[root];leaves=[]
            while pending:
                nlo,nhi,ids,left,right=pending.pop()
                if not(upper[0]>nlo[0]+1e-5 and lower[0]<nhi[0]-1e-5 and upper[1]>nlo[1]+1e-5 and lower[1]<nhi[1]-1e-5 and upper[2]>nlo[2]+1e-5 and lower[2]<nhi[2]-1e-5):continue
                if ids is None:pending.extend([left,right])
                else:leaves.append(ids)
            if not leaves:continue
            ids=np.concatenate(leaves)
            mask=np.all(upper>lo[ids]+1e-5,1)&np.all(lower<hi[ids]-1e-5,1)
            t=target[ids[mask]]
            if not len(t):continue
            dr=end-start;ab=t[:,1]-t[:,0];ac=t[:,2]-t[:,0]
            h=np.cross(dr,ac);det=np.einsum('ij,ij->i',ab,h)
            inv=np.divide(1.,det,out=np.zeros_like(det),where=abs(det)>1e-8)
            tv=start-t[:,0];u=np.einsum('ij,ij->i',tv,h)*inv
            q=np.cross(tv,ab);v=q@dr*inv;f=np.einsum('ij,ij->i',ac,q)*inv
            valid=(abs(det)>1e-8)&(u>1e-5)&(v>1e-5)&(u+v<1-1e-5)&(f>1e-4)&(f<1-1e-4)
            hits.extend((start+f[valid,None]*dr).tolist())
        return np.unique(np.round(hits,4),axis=0).reshape(-1,3)if hits else np.empty((0,3))

    def pair(self,a,b,offset):
        offset=np.asarray(offset)
        alo,ahi=self.bounds[a];blo,bhi=self.bounds[b]
        lower=np.maximum(alo.min(0)+offset,blo.min(0));upper=np.minimum(ahi.max(0)+offset,bhi.max(0))
        if np.any(upper<lower-1e-5):return np.empty((0,3))
        # A real crossing lies in both whole-mesh boxes. Retain every triangle
        # whose own box meets that common volume; no geometry is clipped.
        am=np.all(ahi+offset>=lower-1e-5,1)&np.all(alo+offset<=upper+1e-5,1)
        bm=np.all(bhi>=lower-1e-5,1)&np.all(blo<=upper+1e-5,1)
        if int(am.sum())*int(bm.sum())<2_000_000:
            from audit_final_minifigure import crossings
            aa=self.meshes[a][am]+offset;bb=self.meshes[b][bm]
            return np.concatenate((crossings(aa,bb),crossings(bb,aa)))
        # Reverse the pair in the unshifted target's local translation frame.
        return np.concatenate((self.crossings(a,b,offset),self.crossings(b,a,-offset)+offset))
