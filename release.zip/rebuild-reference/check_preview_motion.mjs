import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire('/Users/clkao/git/spacedock-research/studfleet/package.json');
const {chromium}=require('playwright-core');
const base=process.argv[2]||'http://127.0.0.1:18944/';
const evidence=process.argv[3]||'projects/yangliu-vehicle/evidence/dss-name-2026-11-03';
const browser=await chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1400,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 await page.addInitScript(()=>window.capturePreviewInternals=value=>window.rigInternals=value);
 await page.goto(base);await page.waitForFunction(()=>window.inspectPreviewAnimation?.().running);
 const snapshot=()=>page.evaluate(()=>({animation:inspectPreviewAnimation(),performance:inspectPreviewPerformance(),model:JSON.stringify(PROTOTYPE.model),placements:JSON.stringify(PROTOTYPE.placements),geometries:rigInternals.renderer.info.memory.geometries}));
 const before=await snapshot();await page.waitForTimeout(1200);const after=await snapshot();
 assert.equal(before.model,after.model);assert.equal(before.placements,after.placements);
 assert.equal(before.performance.sceneUpdates,after.performance.sceneUpdates);
 assert.equal(before.geometries,after.geometries);
 assert.notDeepEqual(before.animation.camera,after.animation.camera);
 assert(!after.animation.animatedIds.includes(254),'The helm must stay still');
 assert.equal(after.animation.wheels.length,4);
 for(let i=0;i<4;i++){
  assert(after.animation.wheels[i].angle<before.animation.wheels[i].angle,'Wheels must roll toward the +X front');
  assert.deepEqual(before.animation.wheels[i].center,after.animation.wheels[i].center);
 }
 assert.equal(after.animation.walkingHeading,0);
 assert.deepEqual(before.animation.walkingPosition,after.animation.walkingPosition);
 await page.screenshot({path:evidence+'/animation-preview.png'});
 await page.locator('#toggle-animation').click();await page.waitForTimeout(500);
 const paused=await page.evaluate(()=>inspectPreviewPerformance().renderedFrames);await page.waitForTimeout(600);
 assert.equal(await page.evaluate(()=>inspectPreviewPerformance().renderedFrames),paused);
 await page.locator('#toggle-animation').click();await page.locator('#start-building').click();await page.waitForTimeout(500);
 const building=await page.evaluate(()=>({animation:inspectPreviewAnimation(),instructions:inspectInstructions(),frames:inspectPreviewPerformance().renderedFrames}));
 assert.equal(building.animation.running,false);assert.equal(building.animation.shown,false);
 await page.waitForTimeout(600);assert.equal(await page.evaluate(()=>inspectPreviewPerformance().renderedFrames),building.frames);
 await page.evaluate(()=>setInstructionStep(0));await page.locator('#inspect-tab').click();await page.locator('#explode').check();await page.waitForTimeout(400);
 const shield=await page.evaluate(()=>{const {assembly}=rigInternals;return PROTOTYPE.model.pieces.filter(p=>p.module==='shield').map(p=>({id:p.id,offset:assembly.matrices.get(p.id).elements[13]-assembly.matrix(p).elements[13]}))});
 assert.equal(shield.length,11);assert(shield.every(p=>Math.abs(p.offset-13)<1e-5));
 await page.screenshot({path:evidence+'/shield-exploded-preview.png'});
 const reduced=await browser.newPage({reducedMotion:'reduce'});await reduced.goto(base);await reduced.waitForFunction(()=>window.inspectPreviewAnimation);
 const reducedState=await reduced.evaluate(()=>inspectPreviewAnimation());assert.equal(reducedState.enabled,false);assert.equal(reducedState.running,false);
 assert.deepEqual(errors,[]);
 const result={base,errors,active:{frames:after.performance.renderedFrames-before.performance.renderedFrames,sceneRebuilds:after.performance.sceneUpdates-before.performance.sceneUpdates,geometryAllocations:after.geometries-before.geometries,cameraMoved:true,animatedIds:after.animation.animatedIds,rigs:after.animation.rigs,wheels:after.animation.wheels,helmStatic:true,walkingHeading:0},modelAndPlacementsUnchanged:true,pausedIdleFrames:0,building:{running:building.animation.running,shown:building.animation.shown,step:building.instructions.step},shield,reducedMotion:{enabled:reducedState.enabled,running:reducedState.running}};
 fs.writeFileSync(evidence+'/animation-preview-check.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{await browser.close()}
